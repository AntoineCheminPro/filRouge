<?php

require "view/statisticView.php";
