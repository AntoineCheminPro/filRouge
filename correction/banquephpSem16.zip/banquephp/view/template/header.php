<header class="jumbotron jumbotron-fluid bg-light mt-5">
  <section class="container">
    <h1 class="display-4 border-info border-bottom">Les frères rape-tout</h1>
    <p class="lead">L'argent est un problème, on vous en débarasse</p>
  </section>
</header>

<main class="container">
