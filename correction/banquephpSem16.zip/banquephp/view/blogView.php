<?php
include "template/nav.php";
include "template/header.php";
?>

<h2>En ce moment dans le monde de la banque</h2>
<div class="row mt-5" id="articleContainer">

</div>

<?php
$script = "<script src='public/js/blog.js'></script>";
include "template/footer.php";
?>
