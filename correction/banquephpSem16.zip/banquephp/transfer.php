<?php

include "view/transferView.php";
