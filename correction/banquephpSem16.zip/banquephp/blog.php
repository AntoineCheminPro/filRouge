<?php

require "view/blogView.php";
